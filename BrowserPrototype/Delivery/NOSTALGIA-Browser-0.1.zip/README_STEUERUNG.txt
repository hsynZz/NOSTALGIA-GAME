NOSTALGIA - Prototype 0.1 / Endless Summer 2004

1. Das ZIP vollstaendig entpacken.
2. index.html mit Microsoft Edge oder Google Chrome oeffnen.
3. Im Spiel auf Aufwachen klicken. Zum Umschauen Mausklick ins Spiel; Esc gibt die Maus frei.

WASD: bewegen. Maus: umsehen. Shift: sprinten. Leertaste: springen. C: ducken.
E: interagieren. J: Foto. H: Hinweis. F5: speichern. F9: laden.
Auf Touch-Geraeten: Bildschirmsteuerung; Safari verlangt den Start per Beruehrung fuer Audio.

Die gesamte Testversion liegt in index.html. Kein Unreal Editor, Python, Node oder Internet erforderlich.
WebGL2 muss im Browser verfuegbar sein. Bei einer WebGL-Fehlermeldung Hardwarebeschleunigung im Browser pruefen.

Dies ist die separate Browser-Testversion. Das Unreal-Projekt bleibt das langfristige Hauptprojekt.
Alle Modelle und Klaenge sind einfache Testdarstellungen. Der Gartenklang ist synthetisch erzeugt.
Unterstuetzung und Quellen: https://github.com/hsynZz/NOSTALGIA-GAME
